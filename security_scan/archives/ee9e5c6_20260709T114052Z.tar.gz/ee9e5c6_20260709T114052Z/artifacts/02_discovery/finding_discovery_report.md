# Finding Discovery Report

Scan: ee9e5c6_20260709T114052Z
Scope: repository-wide
Deep-review rows: 131 (full copy of rank_input)
File-review batches: session-api/store; conversation/tools; retrieval/chunking/agent-files; providers/redaction/client; SEED-08 local settings

## Reportable candidates (validation required)

| ID | Title | Seed/Row | Confidence |
|---|---|---|---|
| C-003 | Create-session system prompt bypasses allowClientOverrides | SEED-02 residual | high |
| C-006 | SSE streams ignore client disconnect / AbortSignal | L-16 | medium |
| C-101 | Tool schema validation bypass via __proto__/constructor | L-20 | high |
| C-102 | Required checks via `in` accept prototype properties | L-20 | medium |
| C-103 | Conversation.restore snapshot overrides caller policy/tenant | L-13 | high |
| C-104 | Unbounded maxToolRounds/timeouts from snapshot | L-13 | medium |

## Deferred

| ID | Title | Reason |
|---|---|---|
| C-008 | Compact unbounded maxMessages/maxTokens | Low-confidence self-impact; proof gap on severity |
| C-110 | structured-output no client revalidation | Provider-enforced by design; secondary |

## Suppressed / N/A (seed & family closures)

SEED-01 tool-result redaction; SEED-02 allowlist fields (except C-003 residual); SEED-03 RAG ownership; SEED-04 redaction; SEED-05 path traversal; SEED-06 HTML entities; SEED-07 Gemini cache; SEED-08 Claude Bash(node *); L-09 no built-in auth (library design); L-10 trusted-context tenant; L-11 provider-side image_url SSRF (no local fetch); L-12 auto-exec by design; L-14 parameterized filters; L-15 API key plumbing.

## Coverage note

dist-types/** and Test_Droid/** closed not_applicable. scripts/config secondary deferred after high-impact src review (no network-facing deploy surface).
