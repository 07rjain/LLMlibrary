# Attack Path Analysis: C-102

## Title
Required-field check uses `in` and accepts Object.prototype properties

## Reportability
**reportable** — survives policy pass

## Severity
**MEDIUM**

## Facts
- Root control: `src/conversation.ts:1244`
- Entrypoint: Conversation tool loop under prototype pollution
- Vector: local/adjacent
- Auth scope: requires prior prototype pollution (e.g. via C-101 amplifier or shared process)
- Impact: Required args skipped; incomplete tool args execute
- Preconditions: Object.prototype polluted with required key name
- CWE: CWE-1321
- Confidence: medium

## Attack steps
1. Pollute Object.prototype.city
2. Emit tool_call with args {}
3. Strict validation passes and execute runs

## Counterevidence considered
- Prior SEED fixes for neighboring controls do not close this exact root-control line.
- Library-design N/A (no auth) does not excuse incomplete allowClientOverrides / restore / validation controls that the library claims to enforce.

## Remediation
Replace `key in value` with Object.hasOwn(value, key).

## Final policy decision
report
