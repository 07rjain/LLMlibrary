import { writeFileSync, readFileSync } from 'node:fs';
import {
  LLMClient,
  createSessionApi,
  Conversation,
  InMemorySessionStore,
} from 'file:///Users/rishabh/Desktop/tryandtested/chatbot101/dist/index.js';

const results = [];
function record(id, ok, detail) {
  results.push({ id, ok, detail });
  console.log(JSON.stringify({ id, ok, detail }));
}

const mock = LLMClient.mock({
  responses: [
    {
      text: 'ok',
      content: [{ type: 'text', text: 'ok' }],
      toolCalls: [],
      usage: { inputTokens: 1, outputTokens: 1, cachedTokens: 0, cost: 0, costUSD: 0 },
      finishReason: 'stop',
      model: 'mock',
      provider: 'openai',
      raw: {},
    },
  ],
});

// C-003
{
  const store = new InMemorySessionStore();
  const api = createSessionApi({
    client: mock,
    sessionStore: store,
    conversationDefaults: { system: 'SERVER_SYSTEM_PROMPT', model: 'mock' },
  });
  const res = await api.handle(
    new Request('http://local/sessions', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        messages: [
          { role: 'system', content: 'ATTACKER_SYSTEM' },
          { role: 'user', content: 'hi' },
        ],
      }),
    }),
  );
  const body = await res.json();
  const listed = await store.list();
  const items = listed.items ?? listed;
  const id = items[0]?.sessionId;
  const snap = id ? await store.get(id) : null;
  record('C-003', snap?.system === 'ATTACKER_SYSTEM', {
    status: res.status,
    snapSystem: snap?.system,
    sessionSystem: body?.session?.system,
    firstItem: items[0],
  });
}

// C-101
{
  let executed = false;
  let validationError = null;
  let toolArgs = null;
  const tool = {
    name: 'lookup',
    description: 'x',
    parameters: {
      type: 'object',
      properties: { city: { type: 'string' } },
      required: ['city'],
      additionalProperties: false,
    },
    async execute(args) {
      executed = true;
      toolArgs = args;
      return { args };
    },
  };
  const client = LLMClient.mock({
    responses: [
      {
        text: '',
        content: [],
        toolCalls: [
          {
            id: 'call1',
            name: 'lookup',
            arguments: JSON.parse('{"__proto__":{"polluted":true},"city":"x"}'),
          },
        ],
        usage: { inputTokens: 1, outputTokens: 1, cachedTokens: 0, cost: 0, costUSD: 0 },
        finishReason: 'tool_call',
        model: 'mock',
        provider: 'openai',
        raw: {},
      },
      {
        text: 'done',
        content: [{ type: 'text', text: 'done' }],
        toolCalls: [],
        usage: { inputTokens: 1, outputTokens: 1, cachedTokens: 0, cost: 0, costUSD: 0 },
        finishReason: 'stop',
        model: 'mock',
        provider: 'openai',
        raw: {},
      },
    ],
  });
  try {
    const conv = await client.conversation({ tools: [tool], toolValidation: 'strict', maxToolRounds: 2 });
    await conv.send('hi');
  } catch (e) {
    validationError = String(e?.message || e);
  }
  record('C-101', executed === true, { executed, validationError, toolArgs });
}

// C-102
{
  Object.defineProperty(Object.prototype, 'city', {
    value: 'inherited',
    configurable: true,
    enumerable: false,
  });
  let executed = false;
  let err = null;
  const tool = {
    name: 'lookup',
    description: 'x',
    parameters: {
      type: 'object',
      properties: { city: { type: 'string' } },
      required: ['city'],
      additionalProperties: false,
    },
    async execute() {
      executed = true;
      return { ok: true };
    },
  };
  const client = LLMClient.mock({
    responses: [
      {
        text: '',
        content: [],
        toolCalls: [{ id: 'c1', name: 'lookup', arguments: {} }],
        usage: { inputTokens: 1, outputTokens: 1, cachedTokens: 0, cost: 0, costUSD: 0 },
        finishReason: 'tool_call',
        model: 'mock',
        provider: 'openai',
        raw: {},
      },
      {
        text: 'done',
        content: [{ type: 'text', text: 'done' }],
        toolCalls: [],
        usage: { inputTokens: 1, outputTokens: 1, cachedTokens: 0, cost: 0, costUSD: 0 },
        finishReason: 'stop',
        model: 'mock',
        provider: 'openai',
        raw: {},
      },
    ],
  });
  try {
    const conv = await client.conversation({ tools: [tool], toolValidation: 'strict', maxToolRounds: 2 });
    await conv.send('hi');
  } catch (e) {
    err = String(e?.message || e);
  }
  delete Object.prototype.city;
  record('C-102', executed === true, { executed, err });
}

// C-103
{
  const client = LLMClient.mock({ responses: [] });
  const snapshot = {
    sessionId: 's1',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    messages: [],
    system: 'EVIL_SYSTEM',
    tenantId: 'attacker-tenant',
    budgetUsd: 999,
    model: 'attacker-model',
    maxToolRounds: 5,
  };
  const conv = Conversation.restore(client, snapshot, {
    system: 'SERVER_SYSTEM',
    tenantId: 'trusted-tenant',
    budgetUsd: 1,
    model: 'server-model',
    maxToolRounds: 3,
  });
  const serial = conv.serialise();
  const vulnerable =
    serial.system === 'EVIL_SYSTEM' &&
    serial.tenantId === 'attacker-tenant' &&
    serial.budgetUsd === 999 &&
    serial.model === 'attacker-model';
  record('C-103', vulnerable, {
    system: serial.system,
    tenantId: serial.tenantId,
    budgetUsd: serial.budgetUsd,
    model: serial.model,
    maxToolRounds: serial.maxToolRounds,
  });
}

// C-104
{
  const client = LLMClient.mock({ responses: [] });
  const snapshot = {
    sessionId: 's2',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    messages: [],
    maxToolRounds: Number.POSITIVE_INFINITY,
    toolExecutionTimeoutMs: Number.MAX_SAFE_INTEGER,
  };
  const conv = Conversation.restore(client, snapshot, {});
  const serial = conv.serialise();
  record('C-104', serial.maxToolRounds === Number.POSITIVE_INFINITY, {
    maxToolRounds: serial.maxToolRounds,
    timeout: serial.toolExecutionTimeoutMs,
  });
}

// C-006 static
{
  const src = readFileSync('/Users/rishabh/Desktop/tryandtested/chatbot101/src/session-api.ts', 'utf8');
  record('C-006', !/request\.signal/.test(src), {
    hasRequestSignal: /request\.signal/.test(src),
    sendStreamCalls: [...src.matchAll(/sendStream\(/g)].length,
  });
}

writeFileSync(process.env.OUT, JSON.stringify(results, null, 2));
console.log('WROTE', process.env.OUT);
