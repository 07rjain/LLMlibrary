# Attack Path Analysis: C-104

## Title
Snapshot-restored maxToolRounds/timeouts unbounded when caller omits overrides

## Reportability
**reportable** — survives policy pass

## Severity
**MEDIUM**

## Facts
- Root control: `src/conversation.ts:353`
- Entrypoint: Conversation.restore
- Vector: store integrity
- Auth scope: requires snapshot write
- Impact: Infinity maxToolRounds never trips assertNextToolRound; huge timeouts
- Preconditions: Tampered snapshot; options omit maxToolRounds
- CWE: CWE-770
- Confidence: medium

## Attack steps
1. Set snapshot.maxToolRounds=Infinity
2. Restore without options.maxToolRounds
3. Tool loop bound ineffective

## Counterevidence considered
- Prior SEED fixes for neighboring controls do not close this exact root-control line.
- Library-design N/A (no auth) does not excuse incomplete allowClientOverrides / restore / validation controls that the library claims to enforce.

## Remediation
Clamp maxToolRounds and toolExecutionTimeoutMs to finite positive ranges; reject Infinity/NaN.

## Final policy decision
report
