# Validation Summary

Harness: `05_findings/_harness/results2.json`

| ID | Survives | Method | Notes |
|---|---|---|---|
| C-003 | yes | runtime SessionApi | session.system=ATTACKER_SYSTEM |
| C-006 | yes | static | no request.signal in session-api.ts |
| C-101 | yes | runtime Conversation | execute received __proto__ key |
| C-102 | yes | runtime Conversation | empty args executed under prototype pollution |
| C-103 | yes | runtime Conversation.restore | snapshot system/tenant/budget/model win |
| C-104 | yes | runtime Conversation.restore | Infinity maxToolRounds; assert never trips |

All other candidates closed suppressed/not_applicable/deferred with discovery counterevidence receipts.
