# Attack Path Analysis: C-005

## Reportability
**suppressed** — no reportable attack path (suppressed/not_applicable/deferred)

## Final policy decision
ignore
