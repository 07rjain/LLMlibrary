# Attack Path Analysis: C-401

## Reportability
**suppressed** — no reportable attack path (suppressed/not_applicable/deferred)

## Final policy decision
ignore
