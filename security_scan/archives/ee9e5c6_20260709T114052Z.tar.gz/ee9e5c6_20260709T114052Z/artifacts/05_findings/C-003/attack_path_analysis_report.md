# Attack Path Analysis: C-003

## Title
Create-session history can set system prompt despite deny-by-default allowClientOverrides

## Reportability
**reportable** — survives policy pass

## Severity
**HIGH**

## Facts
- Root control: `src/session-api.ts:320`
- Entrypoint: POST /sessions
- Vector: network
- Auth scope: none (or whatever integrator auth provides; library has none)
- Impact: Attacker-controlled system prompt for new sessions even when allowClientOverrides denies `system`
- Preconditions: SessionApi create endpoint reachable; conversationDefaults.system set by integrator
- CWE: CWE-15, CWE-862
- Confidence: high

## Attack steps
1. POST /sessions with messages[0].role=system content=ATTACKER_SYSTEM (or body.system)
2. Observe session.system == ATTACKER_SYSTEM in 201 response
3. Subsequent messages run under attacker system prompt

## Counterevidence considered
- Prior SEED fixes for neighboring controls do not close this exact root-control line.
- Library-design N/A (no auth) does not excuse incomplete allowClientOverrides / restore / validation controls that the library claims to enforce.

## Remediation
Gate history.system / body.system / leading system messages on allowedClientOverrides.has('system'), same as buildConversationOptions.

## Final policy decision
report
