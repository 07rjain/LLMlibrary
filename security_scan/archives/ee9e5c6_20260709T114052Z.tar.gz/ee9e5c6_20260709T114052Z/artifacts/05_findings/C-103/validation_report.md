# Validation Report: C-103

## Rubric
- [x] Attacker-controlled source identified
- [x] Broken control / sink identified at file:line
- [x] Reachability from product surface established
- [x] Runtime or static evidence collected
- [x] Counterevidence considered

## Assessment
- candidate_id: C-103
- disposition: reportable
- confidence: high
- method: runtime_poc
- evidence: `{"system": "EVIL_SYSTEM", "tenantId": "attacker-tenant", "budgetUsd": 999, "model": "attacker-model", "maxToolRounds": 3}`

## Notes
Validated via dist/index.js harness results2.json
