# Attack Path Analysis: C-103

## Title
Conversation.restore prefers snapshot system/model/budget/tenantId over caller options

## Reportability
**reportable** — survives policy pass

## Severity
**HIGH**

## Facts
- Root control: `src/conversation.ts:350-374`
- Entrypoint: LLMClient.conversation restore / SessionApi message on existing session
- Vector: store integrity / confused deputy
- Auth scope: requires ability to write or tamper ConversationSnapshot in store
- Impact: Restored sessions ignore server policy for system/tenant/budget/model
- Preconditions: Writable or compromised session store; or prior C-003 write of hostile system into snapshot
- CWE: CWE-915
- Confidence: high

## Attack steps
1. Write snapshot with evil system/tenantId/budgetUsd/model
2. Server restores with trusted options
3. Snapshot values win for those fields

## Counterevidence considered
- Prior SEED fixes for neighboring controls do not close this exact root-control line.
- Library-design N/A (no auth) does not excuse incomplete allowClientOverrides / restore / validation controls that the library claims to enforce.

## Remediation
Prefer caller options for system, tenantId, budgetUsd, model, provider, providerOptions, responseFormat; only restore messages/history from snapshot unless explicitly opted in.

## Final policy decision
report
