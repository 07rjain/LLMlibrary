# Attack Path Analysis: C-101

## Title
Strict tool-arg schema validation bypass via __proto__/constructor keys

## Reportability
**reportable** — survives policy pass

## Severity
**HIGH**

## Facts
- Root control: `src/conversation.ts:1251`
- Entrypoint: Conversation tool loop / Session API message with tools
- Vector: adjacent (model-influenced tool args)
- Auth scope: session access
- Impact: additionalProperties:false bypass; polluted-shaped keys reach tool.execute
- Preconditions: Registered tools with strict validation; model emits __proto__/constructor keys
- CWE: CWE-1321
- Confidence: high

## Attack steps
1. Cause model tool_call with args {__proto__:{...}, city:'x'}
2. Strict validator accepts and execute() receives __proto__ own key

## Counterevidence considered
- Prior SEED fixes for neighboring controls do not close this exact root-control line.
- Library-design N/A (no auth) does not excuse incomplete allowClientOverrides / restore / validation controls that the library claims to enforce.

## Remediation
Use Object.hasOwn(properties,key) / Object.create(null) for schema maps; reject __proto__/constructor/prototype keys; throw on unknown schema.type.

## Final policy decision
report
