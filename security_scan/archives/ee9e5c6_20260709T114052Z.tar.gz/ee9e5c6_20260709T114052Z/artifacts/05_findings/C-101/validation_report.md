# Validation Report: C-101

## Rubric
- [x] Attacker-controlled source identified
- [x] Broken control / sink identified at file:line
- [x] Reachability from product surface established
- [x] Runtime or static evidence collected
- [x] Counterevidence considered

## Assessment
- candidate_id: C-101
- disposition: reportable
- confidence: high
- method: runtime_poc
- evidence: `{"executed": true, "hasProtoKey": true, "toolArgs": {"__proto__": {"polluted": true}, "city": "x"}, "isError": false, "result": {"args": {"__proto__": {"polluted": true}, "city": "x"}}}`

## Notes
Validated via dist/index.js harness results2.json
