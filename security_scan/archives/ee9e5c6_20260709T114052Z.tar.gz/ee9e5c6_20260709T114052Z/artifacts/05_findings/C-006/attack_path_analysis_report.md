# Attack Path Analysis: C-006

## Title
SSE stream path lacks AbortSignal / client-disconnect cancellation

## Reportability
**reportable** — survives policy pass

## Severity
**MEDIUM**

## Facts
- Root control: `src/session-api.ts:685`
- Entrypoint: POST /sessions/{id}/message?stream=true
- Vector: network
- Auth scope: integrator-dependent
- Impact: LLM/tool work continues after client disconnect; resource/cost exhaustion
- Preconditions: Stream endpoint reachable; costly model/tools
- CWE: CWE-400
- Confidence: medium

## Attack steps
1. Open many stream=true requests
2. Disconnect clients early
3. Observe server-side sendStream continues (no request.signal wiring)

## Counterevidence considered
- Prior SEED fixes for neighboring controls do not close this exact root-control line.
- Library-design N/A (no auth) does not excuse incomplete allowClientOverrides / restore / validation controls that the library claims to enforce.

## Remediation
Pass request.signal into conversation.sendStream; abort on ReadableStream cancel; add concurrency limits at integrator edge.

## Final policy decision
report
