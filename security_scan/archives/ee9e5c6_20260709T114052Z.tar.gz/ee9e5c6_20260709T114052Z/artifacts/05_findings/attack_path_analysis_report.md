# Attack Path Analysis Summary

Surviving reportable findings: C-003, C-006, C-101, C-102, C-103, C-104.

Severity calibration (threat model):
- C-003 HIGH (policy/system prompt downgrade on public create)
- C-101 HIGH (strict validation bypass to tool.execute)
- C-103 HIGH (snapshot overrides server policy/tenant)
- C-006 MEDIUM (availability / cost DoS)
- C-102 MEDIUM (requires pollution precondition; pairs with C-101)
- C-104 MEDIUM (availability; store integrity precondition)
