# Attack Path Analysis: C-106

## Reportability
**suppressed** — no reportable attack path (suppressed/not_applicable/deferred)

## Final policy decision
ignore
