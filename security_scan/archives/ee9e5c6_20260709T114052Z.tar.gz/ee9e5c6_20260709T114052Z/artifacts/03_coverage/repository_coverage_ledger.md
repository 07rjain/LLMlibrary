# Repository Coverage Ledger

Scan: ee9e5c6_20260709T114052Z
Scope: repository-wide (.)
Threat model: artifacts/01_context/threat_model.md
Deep-review worklist: 131 rows (top-percent 100 / full copy)

## Dominant runtime areas

| Shard | Area | Files | Families in scope |
|---|---|---|---|
| S-SESSION | Session API HTTP boundary | src/session-api.ts | authz/tenant, sensitive exposure, policy downgrade, DoS |
| S-CONV | Conversation + tools | src/conversation.ts, src/tools.ts | injection via tools, validation bypass, RCE via consumer tools |
| S-RAG | Retrieval / knowledge | src/retrieval.ts, src/chunking.ts | cross-tenant, injection, parser DoS |
| S-STORE | Session stores | src/session-store.ts | tenant IDOR, deserialization |
| S-PROV | Provider adapters | src/providers/*.ts | path injection, SSRF (provider-side), secret headers |
| S-AGENT | Agent files | src/agent-files.ts | path traversal / arbitrary file read |
| S-REDACT | Redaction / errors / usage | src/redaction.ts, src/errors.ts, src/usage.ts | secret leakage |
| S-CLIENT | Client dispatch / budgets / router | src/client.ts, src/router.ts, src/runtime.ts | budget bypass, key handling |
| S-STREAM | Streaming / SSE | src/stream-control.ts, src/utils/parse-sse.ts | DoS, event injection |
| S-BUILD | dist-types emit | dist-types/src/** | mirror of src (N/A independent) |
| S-TESTFIX | Test_Droid | Test_Droid/** | test-only |
| S-DEV | scripts/config | scripts/*, configs | secondary |
| S-LOCAL | .claude settings | .claude/settings.local.json | local tooling footgun (SEED-08) |

## High-impact family rows

| Row ID | Seed | Boundary | Family | Files checked | Source/boundary | Sink/control | Candidate IDs | Disposition | Evidence |
|---|---|---|---|---|---|---|---|---|---|
| L-01 | SEED-01 | S-SESSION | sensitive data exposure (tool results) | src/session-api.ts | HTTP message/stream | exposeToolResults / projectMessages | TBD | open | regression seed |
| L-02 | SEED-02 | S-SESSION | authz/policy downgrade | src/session-api.ts | request body options | allowClientOverrides | TBD | open | regression seed |
| L-03 | SEED-03 | S-RAG | cross-tenant overwrite | src/retrieval.ts | upsert id | assertKnowledgeRecordOwnership | TBD | open | regression seed |
| L-04 | SEED-04 | S-REDACT | secret redaction bypass | src/redaction.ts | log/error objects | sanitizeForLogging | TBD | open | regression seed |
| L-05 | SEED-05 | S-AGENT | path traversal | src/agent-files.ts | loadSkill(string) | assertWithinRoot | TBD | open | regression seed |
| L-06 | SEED-06 | S-RAG | parser crash/DoS | src/chunking.ts | HTML entities | isValidCodePoint | TBD | open | regression seed |
| L-07 | SEED-07 | S-PROV | path injection | src/providers/gemini.ts | cache name | normalizeGeminiCachedContentName | TBD | open | regression seed |
| L-08 | SEED-08 | S-LOCAL | local command allowlist | .claude/settings.local.json | Claude Bash allow | Bash(node *) | TBD | open | regression seed |
| L-09 | | S-SESSION | missing authn (library) | src/session-api.ts | createSessionApi | no built-in auth | TBD | open | threat model |
| L-10 | | S-SESSION | tenant IDOR / resolution | src/session-api.ts, src/session-store.ts | tenantResolution | trusted-context vs legacy | TBD | open | threat model |
| L-11 | | S-PROV | SSRF via image_url | src/providers/*.ts, src/types.ts | Canonical image parts | provider fetch of URL | TBD | open | threat model |
| L-12 | | S-CONV | tool auto-exec confused deputy | src/conversation.ts | model tool args | executeToolWithGuards | TBD | open | threat model |
| L-13 | | S-STORE | session snapshot trust | src/session-store.ts, src/conversation.ts | persisted JSON | restore tools/policy | TBD | open | threat model |
| L-14 | | S-RAG | query/filter injection | src/retrieval.ts | metadata filters | SQL/params | TBD | open | high-impact family |
| L-15 | | S-CLIENT | API key handling | src/client.ts, src/runtime.ts | env/constructor | headers/logs | TBD | open | secondary-enabling |
| L-16 | | S-STREAM | SSE abuse / DoS | src/session-api.ts, parse-sse | stream endpoints | unbounded stream | TBD | open | availability |
| L-17 | | S-BUILD | generated dist drift | dist-types/** | n/a | parity with src | | not_applicable | Generated; review src |
| L-18 | | S-TESTFIX | test fixtures | Test_Droid/** | n/a | n/a | | not_applicable | Not deployed |
| L-19 | | S-DEV | CI/scripts | scripts/** | local/CI | n/a | | deferred | Secondary after src; no network-facing deploy |
| L-20 | | S-CONV | prototype pollution in tool args | src/conversation.ts | tool JSON args | schema validate | TBD | open | high-impact adjacent |

Rows L-01..L-16 and L-20 remain open pending deep file review. L-17/L-18 closed N/A. L-19 deferred secondary.


## Closure update

- L-01: suppressed (SEED-01 / C-001)
- L-02: reportable residual C-003 (allowlist OK; create system bypass)
- L-03: suppressed (SEED-03 / C-201)
- L-04: suppressed (SEED-04 / C-301)
- L-05: suppressed (SEED-05 / C-202)
- L-06: suppressed (SEED-06 / C-203)
- L-07: suppressed (SEED-07 / C-302)
- L-08: suppressed (SEED-08 / C-401)
- L-09: not_applicable (C-004 library design)
- L-10: suppressed (C-005)
- L-11: suppressed (C-303 provider-side only)
- L-12: suppressed (C-105 by design)
- L-13: reportable C-103/C-104
- L-14: suppressed (C-204)
- L-15: suppressed (C-304)
- L-16: reportable C-006
- L-20: reportable C-101/C-102
