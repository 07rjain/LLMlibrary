# Dedupe Report

- No cross-file duplicates collapsed.
- C-001/C-002 suppressed independently from reportable C-003 (create-session system bypass is a distinct incomplete control).
- C-101 and C-102 are sibling prototype-validation instances (separate root-control lines); both retained.
- C-103 and C-104 share snapshot-trust family but distinct impacts (policy vs availability); both retained.
- C-007 N/A superseded by C-401 for SEED-08 closure.
- Provider SSRF (C-303) suppressed as non-local sink per threat model; residual noted in coverage ledger.
