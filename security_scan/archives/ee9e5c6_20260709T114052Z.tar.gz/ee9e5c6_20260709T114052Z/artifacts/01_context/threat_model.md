# Threat Model: unified-llm-client (chatbot101)

## Overview

`unified-llm-client` is a provider-agnostic TypeScript LLM client library (npm package) that unifies Anthropic, OpenAI, and Gemini behind canonical types. It ships as a library (`dist/`), not a deployable SaaS application. Documented product context describes a multi-tenant chatbot widget SaaS that would embed this library for Session API, tool calling against tenant databases, RAG, and usage accounting — but that widget app is **not implemented in this repository**.

Primary runtime surfaces in-repo:

- `LLMClient` completion/streaming/embeddings dispatch (`src/client.ts`)
- Stateful `Conversation` with auto tool execution (`src/conversation.ts`)
- Framework-agnostic HTTP Session API (`src/session-api.ts`)
- Session stores: in-memory, Postgres, Redis (`src/session-store.ts`)
- RAG / knowledge stores and retrieval (`src/retrieval.ts`, `src/chunking.ts`)
- Provider adapters using raw `fetch` (`src/providers/*`)
- Agent instruction/skill file loading, Node-only (`src/agent-files.ts`)
- Usage logging and secret redaction (`src/usage.ts`, `src/redaction.ts`)
- Model routing, budgets, context managers (`src/router.ts`, `src/context-manager.ts`)

Intended real-world usage: integrators mount `createSessionApi()` behind their own auth middleware, inject server-side tools, persist sessions with tenant-scoped stores, and optionally use RAG against Postgres/pgvector. Edge-safe core; Node-only loaders for `pg` and `js-tiktoken`.

## Threat Model, Trust Boundaries, and Assumptions

### Actors

- **End user / widget visitor**: sends chat messages and multimodal parts through the integrator's HTTP surface.
- **Integrator / tenant operator**: configures bots, tools, knowledge bases, and mounts Session API.
- **Library consumer process**: holds provider API keys and DB credentials; runs tool `execute()` callbacks.
- **LLM providers**: return model text and tool-call arguments that the library may auto-execute.
- **Attacker**: unauthenticated or authenticated-as-tenant client able to hit Session API or supply content that reaches adapters, stores, or tools.

### Trust boundaries

1. **HTTP Session API boundary** — Request bodies, query params, URL session IDs, and SSE clients are untrusted. The library provides **no built-in authentication**; authn/authz is assumed to live in consumer `middleware`.
2. **Trusted request context** — `tenantId` (and related RLS hooks) must come from middleware/`withRequestContext`, not from client-supplied body/query fields in default `trusted-context` mode.
3. **Server-side policy** — Conversation policy (`toolValidation`, budgets, model, system prompt, tools) is server-owned. Client overrides are deny-by-default via `allowClientOverrides`.
4. **Model → tool boundary** — Tool-call arguments from providers are untrusted input to `CanonicalTool.execute()`. The library validates against schemas (strict by default) but does not sandbox side effects.
5. **Persistence boundary** — Session snapshots and knowledge records in stores are trusted only as far as store access control and tenant scoping allow.
6. **Filesystem boundary (Node)** — `agent-files` reads local paths; string skill paths require a trusted root and must stay inside it.
7. **Provider network boundary** — Adapters send authenticated requests to Anthropic/OpenAI/Gemini. User-supplied `image_url` values may cause **provider-side** fetches (SSRF class at provider, not local fetch by this library).
8. **Environment / secrets boundary** — API keys and `DATABASE_URL` are operator-controlled; must not leak into logs, SSE, or client responses.

### Assumptions

- Consumers authenticate Session API callers and bind `tenantId` before handlers run.
- Tools registered with Session API / Conversation enforce their own authorization and are read-only or least-privilege where they touch tenant DBs.
- Postgres RLS (documented for the widget SaaS) is an application-layer concern; the library helps thread `tenantId` but does not implement RLS policies.
- Prior June 2026 Codex findings (tool-result exposure, client policy override, RAG tenant reassignment, redaction gaps, skill path traversal, HTML entity crash, Gemini cache path injection, local Claude Node wildcard) are treated as **known fixed controls** to re-verify, not as the sole discovery focus.

### Invariants the code should preserve

- Deny-by-default client policy overrides on Session API.
- Tool results redacted in JSON/SSE unless `exposeToolResults` is explicitly enabled.
- Tenant identity from trusted context by default; reject request-supplied tenant IDs in that mode.
- Executable tools are server-injected, not restored from client-controlled snapshots.
- RAG upserts cannot reassign knowledge IDs across tenants/bots.
- Strict tool argument validation by default.
- Skill path loads cannot escape a required trusted root.
- Gemini cached-content names are grammar-constrained before URL use.
- Logging/error paths redact secret-shaped fields and credential patterns.
- Document HTML entity decoding does not throw on invalid code points.
- Pagination limits bound list endpoints.

## Attack Surface, Mitigations, and Attacker Stories

### Attack surfaces

| Surface | Why it matters |
|---|---|
| `createSessionApi` HTTP handler | Primary external API shape for chat SaaS; CRUD sessions, message, stream, compact, fork |
| Conversation tool loop | Auto-executes model-chosen tools with timeouts/rounds |
| Provider adapters | Authenticated egress; path/header construction; multimodal content forwarding |
| RAG upsert/search | Cross-tenant data isolation; injection into filters/metadata |
| Session stores | Cross-tenant session IDOR if tenant key omitted or wrong |
| Chunking / HTML normalize | DoS or parser crashes on hostile documents |
| Agent file loading | Local file disclosure if root checks fail |
| Redaction / usage logging | Secret and PII leakage via logs or error payloads |
| Client override allowlists | Footgun if integrators enable broad overrides |

### Existing mitigations (material)

- Session API deny-by-default `allowClientOverrides` and `exposeToolResults: false`
- `tenantResolution: 'trusted-context'` default
- `sanitizeForLogging` / safe error messages
- RAG ownership asserts on upsert conflict
- Skill `assertWithinRoot` / path containment
- Gemini `normalizeGeminiCachedContentName`
- Tool validation modes, `maxToolRounds`, tool timeouts
- Security-focused tests under `test/` and prior regression PoCs documented in `security_scan/`

### Realistic attacker stories

- Unauthenticated or weakly authenticated client hits Session API and reads/writes sessions if middleware is missing.
- Client attempts to set `toolValidation: permissive` or raise budgets via request body.
- Client or model causes tool results containing secrets/PII to be returned over SSE.
- Attacker crafts knowledge IDs to overwrite another tenant's RAG records.
- Attacker supplies skill path `../` strings to read host files (Node agent-files consumers).
- Attacker supplies malicious Gemini cache name to alter authenticated API paths.
- Attacker uploads hostile HTML/entities to crash ingestion or burn CPU.
- Attacker embeds internal URLs in `image_url` parts hoping the provider fetches them (SSRF via provider).
- Compromised or malicious model output tricks a privileged tool into exfiltrating tenant DB data (authorization bug in consumer tool, amplified by auto-execute).

### Out of scope / less realistic here

- Classic browser XSS in a first-party SPA (no widget UI in this repo).
- Direct SQL injection into the library's own query builders where parameterized APIs are used — still review, but less central than Session API / tenant / tool boundaries.
- Stealing provider keys from a well-hardened host without process compromise.
- Full widget API-key lifecycle (`cbw_live_*`) — documented only, not implemented in-repo.

### Vulnerability classes that matter most

1. Broken authn/authz and tenant isolation at Session API / store / RAG boundaries
2. Sensitive data exposure (tool results, secrets in logs/SSE/errors)
3. Server-side policy downgrade via client-controlled options
4. Path traversal / local file read in agent-files
5. Injection into provider URL/path construction
6. Availability issues in parsers, streaming, and tool loops
7. Unsafe defaults / secure-by-default footguns for library consumers

### Classes less severe or contextual

- CSRF: depends on how consumers expose cookies/sessions; library is Request/Response agnostic
- Prototype pollution: relevant mainly if untrusted objects merge into prototypes before tool execution
- Dependency CVEs: secondary; still worth seed research for direct deps

## Severity Calibration

### Critical

- Unauthenticated cross-tenant read/write of sessions or knowledge with realistic deploy defaults
- Remote exfiltration of provider API keys or tenant DB credentials through library response/log paths without unusual integrator misconfiguration
- Example: Session API returns another tenant's full conversation including raw tool DB dumps by default

### High

- Client can disable tool validation or raise spend budgets on a public Session API without explicit server allowlist
- Path traversal in `loadSkill` allowing arbitrary file read when using documented APIs
- RAG ID reuse reassigns or overwrites another tenant's documents
- Example: public body sets `exposeToolResults` equivalent behavior or bypasses redaction

### Medium

- Secret-shaped fields miss redaction in a secondary log path
- Provider cache/path injection caught only partially
- DoS via large streams/documents without integrator limits
- Example: prefixed API key field appears in usage logger payload

### Low

- Hardening gaps that require already-privileged operators
- Documentation/footgun issues with clear secure defaults elsewhere
- Example: legacy tenant resolution mode remains available for internal use and is easy to misuse if selected intentionally

## References (grounding)

- `src/session-api.ts`, `src/conversation.ts`, `src/retrieval.ts`, `src/agent-files.ts`, `src/redaction.ts`, `src/providers/gemini.ts`, `src/chunking.ts`, `src/session-store.ts`
- `SESSION_API.md`, `AGENTS.md`
- Prior audits under `security_scan/` (historical; re-verify rather than assume)
