# Seed Research

## Scope of seed inputs

- User request: repository-wide security scan; no CVE/GHSA/advisory IDs supplied.
- Prior Codex Security report (2026-06-30) and verification (2026-07-04 / 2026-07-07) under `security_scan/` document eight historical findings marked fixed. These are treated as **regression seed anchors**, not as proof of current vulnerability.

## Authoritative sources searched

- Local prior reports: `security_scan/codex_security_scan_20260630_report.md`, `security_scan/security_audit_verification_20260704.md`, `security_scan/security_audit_final_verification_20260707.md`
- Package metadata: `package.json` dependencies (direct runtime deps are minimal; adapters use raw `fetch`)
- No external advisory API query required: user did not supply advisory identifiers; npm audit not treated as authoritative for this code-review scan.

## Regression seed anchors (exact historical tuples)

| Seed ID | Family | Anchor files / controls | Prior status |
|---|---|---|---|
| SEED-01 | sensitive data exposure | `src/session-api.ts` tool-result projection / SSE | Fixed (verify) |
| SEED-02 | policy downgrade | `src/session-api.ts` `allowClientOverrides` | Fixed (verify) |
| SEED-03 | cross-tenant RAG | `src/retrieval.ts` ownership asserts | Fixed (verify) |
| SEED-04 | secret redaction | `src/redaction.ts` prefixed keys | Fixed (verify) |
| SEED-05 | path traversal | `src/agent-files.ts` `loadSkill` root | Fixed (verify) |
| SEED-06 | parser DoS/crash | `src/chunking.ts` HTML entities | Fixed (verify) |
| SEED-07 | path injection | `src/providers/gemini.ts` cache name normalize | Fixed (verify) |
| SEED-08 | local tooling footgun | `.claude/settings.local.json` Bash(node *) | Fixed locally (verify) |

## Failed / unavailable lookups

- No GHSA/CVE identifiers provided by user → no advisory-specific file/hunk mapping beyond regression seeds.
- Widget SaaS auth (`cbw_live_*`) not implemented in-repo → no seed targets for that surface.

## Candidate files/functions from seeds

All anchors above plus supporting: `src/conversation.ts`, `src/session-store.ts`, `src/client.ts`, `src/errors.ts`, `src/usage.ts`, provider adapters.
